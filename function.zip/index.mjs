import { DynamoDBDocumentClient, GetCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";

const ddbClient = new DynamoDBClient({ region: "eu-west-3" });
const ddbDocClient = DynamoDBDocumentClient.from(ddbClient);

const tableName = "UserAttributes";

export const handler = async (event) => {
  const userId = event.requestContext.identity.cognitoIdentityId;

  const params = {
    TableName: tableName,
    Key: {
      userId: userId,
    },
  };

  try {
    const result = await ddbDocClient.send(new GetCommand(params));
    if (!result.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: "Utilisateur non trouvé." }),
      };
    }
    return {
      statusCode: 200,
      body: JSON.stringify(result.Item),
    };
  } catch (error) {
    console.error("Erreur lors de la récupération des données :", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Impossible de récupérer les données utilisateur." }),
    };
  }
};